---
title: Microsoft for Startups
description: OpenPanel was selected to join the renowned “Microsoft for Startups” program. 🎉
slug: openpanel-selected-to-join-microsoft-for-startups-program
authors: stefanpejcic
tags: [OpenPanel, news, microsoft]
image: https://openpanel.co/img/blog/openpanel-part-of-the-microsoft-for-startups-program.png
hide_table_of_contents: true
---

OpenPanel was selected to join the renowned “Microsoft for Startups” program, designed for high potnetial startups leading their domains with innovations & disruptive offerings.


<!--truncate-->

We are thrilled to announce that OpenPanel has been accepted into the Microsoft for Startups Founders Hub program 🎉 This incredible opportunity will provide us with invaluable resources, mentorship, and support from one of the world’s leading technology companies.


We are deeply grateful for this recognition and the chance to accelerate our journey with the backing of this program. This partnership will enable us to leverage new cutting-edge technology from OpenAI plus a global network of Microsoft engineers.
A huge thank you to @Microsoft for Startups team for believing in our vision and giving us this platform to grow and succeed. We are eager to collaborate, learn, and make the most of this amazing opportunity.
