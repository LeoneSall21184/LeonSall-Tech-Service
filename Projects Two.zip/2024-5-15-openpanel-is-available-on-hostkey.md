---
title: OpenPanel is now available on HostKey
description: OpenPanel can now be installed with a single click on HostKey VPS and Dedicated servers.
slug: openpanel-is-available-on-hostkey
authors: stefanpejcic
tags: [OpenPanel, news, hostkey]
image: https://openpanel.co/img/blog/openpanel-is-available-on-hostkey.png
hide_table_of_contents: true
---
 
OpenPanel can now be installed with a single click on [HostKey VPS and Dedicated servers](https://hostkey.com/apps/hosting-control-panels/).

<!--truncate-->

[Documentation](https://hostkey.com/documentation/marketplace/hosting_control_panels/openpanel/)
 
