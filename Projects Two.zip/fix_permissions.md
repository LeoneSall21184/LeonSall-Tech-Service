---
sidebar_position: 8
---

# Fix Permissions

