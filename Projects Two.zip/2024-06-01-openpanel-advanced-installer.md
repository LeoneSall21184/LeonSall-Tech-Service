---
title: OpenPanel Advanced installer
description: Create custom install command
slug: openpanel-advanced-installer
authors: stefanpejcic
tags: [OpenPanel, news, install]
image: https://openpanel.co/img/blog/advanced_installer.png
hide_table_of_contents: true
---

https://openpanel.co/install page allows you to customize the OpenPanel installation process.

<!--truncate-->

[Advanced OpenPanel installer](https://openpanel.co/install) is now available and you can use it to view all the available flags when installing OpenPanel, install optional features anc change the configuration.

