---
sidebar_position: 1
---

# Change Root Password

*OpenAdmin > Server >  Change Root Password* allows Administrators to change password for the ssh root user.

![root password](/img/admin/change_root_pass.png)
