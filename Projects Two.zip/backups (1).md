---
sidebar_position: 2
---

# Backup & Restore

The Backups interface lists available backups and can be used to restore account data from a previous point in time.

You can restore:

- All files and folders (entire /home/$username/ directory)
- Individual databases


## Restoring Backup


### Restore a Database


### Restore Files
