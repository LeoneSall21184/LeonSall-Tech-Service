Content and github workflow for the demo websites https://openpanel.co/demo 
